<?php
	setcookie("cit_username","",time()-3600);
	header("location:index.php");
?>
