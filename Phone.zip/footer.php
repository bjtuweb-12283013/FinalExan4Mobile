<?php
$str_footer = 
'<div data-role="footer" data-position="fixed">
      <div data-role="navbar">
          <ul>
          	<li><a href="index.php" data-icon="plus">主页</a></li>
            <li><a href="news.php" data-icon="plus">党政要闻</a></li>
            <li><a href="policy.php" data-icon="minus">政策法规</a></li>
            <li><a href="answer.php" data-icon="delete">在线答题</a></li>
            <li><a href="me.php" data-icon="check">我</a></li>
          </ul>
      </div>
  </div>';
  echo $str_footer;
?>
